create definer = root@localhost view contaquantiviaggi as
(
select `v`.`CodiceTransponder` AS `CodiceTransponder`,
       `e`.`TargaVeicolo`      AS `TargaVeicolo`,
       `e`.`NomeCasello`       AS `NomeCasello`,
       `e`.`OrarioUscita`      AS `OrarioUscita`,
       `e`.`Tariffa`           AS `Tariffa`
from (`telepass`.`esce` `e` join `telepass`.`veicolo` `v` on (`e`.`TargaVeicolo` = `v`.`TargaVeicolo`)));

